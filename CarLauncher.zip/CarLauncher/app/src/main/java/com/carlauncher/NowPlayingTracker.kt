package com.carlauncher

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationManagerCompat

data class Track(
    val title: String,
    val artist: String,
    val art: Bitmap?,
    val sessionActivity: PendingIntent?,
    val playing: Boolean,
    val controls: MediaController.TransportControls
)

/**
 * Следит за активными медиаплеерами и сообщает, что сейчас играет.
 * Вызывать start()/stop() из основного потока.
 */
class NowPlayingTracker(
    private val context: Context,
    private val onUpdate: (Track?) -> Unit
) {
    private val manager =
        context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val listenerComponent = ComponentName(context, MediaListenerService::class.java)
    private val main = Handler(Looper.getMainLooper())

    private var started = false
    private var controllers: List<MediaController> = emptyList()

    // Обложка, загруженная по ссылке (если плеер не передал готовую картинку)
    private var uriKey: String? = null
    private var uriArt: Bitmap? = null

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> setControllers(list) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = publish()
        override fun onPlaybackStateChanged(state: PlaybackState?) = publish()
        override fun onSessionDestroyed() = publish()
    }

    fun hasAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

    fun start() {
        started = true
        if (!hasAccess()) {
            onUpdate(null)
            return
        }
        try {
            manager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent)
            setControllers(manager.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            onUpdate(null)
        }
    }

    fun stop() {
        started = false
        try {
            manager.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (e: Exception) {
            // уже снят
        }
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = emptyList()
    }

    private fun setControllers(list: List<MediaController>?) {
        controllers.forEach { it.unregisterCallback(callback) }
        controllers = list.orEmpty()
        controllers.forEach { it.registerCallback(callback) }
        publish()
    }

    private fun publish() {
        if (!started) return

        // Предпочитаем плеер, который играет прямо сейчас
        val controller = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull { it.metadata != null }

        val md = controller?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)

        if (controller == null || md == null || title.isNullOrBlank()) {
            onUpdate(null)
            return
        }

        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: ""

        var art: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

        if (art == null) {
            val uri = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
            art = artFromUri(uri, "$title|$artist")
        }

        onUpdate(
            Track(
                title = title,
                artist = artist,
                art = art,
                sessionActivity = controller.sessionActivity,
                playing = controller.playbackState?.state == PlaybackState.STATE_PLAYING,
                controls = controller.transportControls
            )
        )
    }

    /** Загружает обложку из content:// или file:// в фоне и обновляет экран, когда она готова. */
    private fun artFromUri(uri: String?, key: String): Bitmap? {
        if (uri == null || !(uri.startsWith("content:") || uri.startsWith("file:"))) return null
        if (key == uriKey) return uriArt

        uriKey = key
        uriArt = null
        Thread {
            val bitmap = try {
                context.contentResolver.openInputStream(Uri.parse(uri))?.use {
                    BitmapFactory.decodeStream(it)
                }
            } catch (e: Exception) {
                null
            }
            main.post {
                if (uriKey == key && bitmap != null) {
                    uriArt = bitmap
                    publish()
                }
            }
        }.start()
        return null
    }
}
