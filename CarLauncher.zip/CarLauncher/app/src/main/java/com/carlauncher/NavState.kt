package com.carlauncher

import android.os.Handler
import android.os.Looper

/** Последние подсказки навигатора, прочитанные из уведомления Waze. */
data class NavInfo(val line1: String, val line2: String)

/**
 * Хранит текущие подсказки навигатора. Сервис уведомлений пишет сюда,
 * главный экран подписывается. Всё живёт в одном процессе, поэтому достаточно обычного объекта.
 */
object NavState {
    private val main = Handler(Looper.getMainLooper())
    private var listener: ((NavInfo?) -> Unit)? = null

    @Volatile
    var current: NavInfo? = null
        private set

    fun update(info: NavInfo?) {
        current = info
        main.post { listener?.invoke(info) }
    }

    /** Подписаться на изменения. Сразу вызывает слушателя с текущим значением. */
    fun subscribe(onChange: (NavInfo?) -> Unit) {
        listener = onChange
        onChange(current)
    }

    fun unsubscribe() {
        listener = null
    }
}
