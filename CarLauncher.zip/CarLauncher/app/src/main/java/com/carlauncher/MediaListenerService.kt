package com.carlauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Сервис уведомлений. Он нужен для двух вещей:
 * 1. Чтобы Android разрешил читать название трека и обложку из медиаплееров.
 * 2. Чтобы показывать подсказки маршрута Waze (читаем его постоянное уведомление).
 */
class MediaListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            val waze = activeNotifications.orEmpty().firstOrNull { it.packageName == WAZE_PACKAGE }
            NavState.update(waze?.let(::toNavInfo))
        } catch (e: Exception) {
            NavState.update(null)
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == WAZE_PACKAGE) NavState.update(toNavInfo(sbn))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName == WAZE_PACKAGE) NavState.update(null)
    }

    private fun toNavInfo(sbn: StatusBarNotification): NavInfo? {
        val extras = sbn.notification.extras ?: return null
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty().trim()
        val sub = extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty().trim()

        val second = listOf(text, sub).filter { it.isNotEmpty() }.joinToString(" · ")
        if (title.isEmpty() && second.isEmpty()) return null
        return if (title.isEmpty()) NavInfo(second, "") else NavInfo(title, second)
    }

    companion object {
        const val WAZE_PACKAGE = "com.waze"
    }
}
