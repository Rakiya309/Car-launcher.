package com.carlauncher

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.RoundedBitmapDrawableFactory
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()

    private lateinit var gridAdapter: AppAdapter
    private lateinit var drawer: View

    private lateinit var albumArt: ImageView
    private lateinit var trackTitle: TextView
    private lateinit var trackArtist: TextView
    private lateinit var btnPlay: ImageView
    private lateinit var controls: View
    private lateinit var speedValue: TextView
    private lateinit var wazeLine1: TextView
    private lateinit var wazeLine2: TextView

    private lateinit var tracker: NowPlayingTracker
    private lateinit var speedTracker: SpeedTracker

    private var currentTrack: Track? = null
    private var receiverRegistered = false
    private var askedLocationPermission = false

    // Обновляем список, когда приложение установлено, удалено или изменено
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    private val locationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) speedTracker.start()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        drawer = findViewById(R.id.drawer)
        albumArt = findViewById(R.id.albumArt)
        trackTitle = findViewById(R.id.trackTitle)
        trackArtist = findViewById(R.id.trackArtist)
        btnPlay = findViewById(R.id.btnPlay)
        controls = findViewById(R.id.controls)
        speedValue = findViewById(R.id.speedValue)
        wazeLine1 = findViewById(R.id.wazeLine1)
        wazeLine2 = findViewById(R.id.wazeLine2)

        tracker = NowPlayingTracker(this, ::showTrack)
        speedTracker = SpeedTracker(this, ::showSpeed)

        gridAdapter = AppAdapter(R.layout.item_app, ::launch)

        findViewById<RecyclerView>(R.id.appGrid).apply {
            layoutManager = GridLayoutManager(this@MainActivity, GRID_COLUMNS)
            adapter = gridAdapter
            setHasFixedSize(true)
        }

        // Плитка «Аудио» и кнопки управления треком
        findViewById<View>(R.id.tileAudio).setOnClickListener { onAudioTileClick() }
        findViewById<View>(R.id.btnPrev).setOnClickListener { currentTrack?.controls?.skipToPrevious() }
        findViewById<View>(R.id.btnNext).setOnClickListener { currentTrack?.controls?.skipToNext() }
        btnPlay.setOnClickListener { togglePlayback() }

        // Навигатор
        findViewById<View>(R.id.tileWaze).setOnClickListener { openWaze() }

        // Нижняя полоса
        findViewById<View>(R.id.tileBluetooth).setOnClickListener {
            safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        findViewById<View>(R.id.tileSettings).setOnClickListener {
            safeStart(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        findViewById<View>(R.id.tileApps).setOnClickListener { setDrawerVisible(true) }
        findViewById<View>(R.id.btnCloseDrawer).setOnClickListener { setDrawerVisible(false) }

        // Если разрешения на геолокацию нет, нажатие на скорость запрашивает его снова
        findViewById<View>(R.id.speedCard).setOnClickListener {
            if (!speedTracker.hasPermission()) {
                locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        // «Назад» закрывает экран приложений, а на главном экране ничего не делает
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                setDrawerVisible(false)
            }
        })

        loadApps()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
        receiverRegistered = true

        tracker.start()
        NavState.subscribe(::showNav)

        speedTracker.start()
        if (!speedTracker.hasPermission() && !askedLocationPermission) {
            askedLocationPermission = true
            locationPermission.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    override fun onStop() {
        super.onStop()
        // После запуска приложения или ухода на другой экран возвращаемся на главный
        setDrawerVisible(false)
        tracker.stop()
        speedTracker.stop()
        NavState.unsubscribe()
        if (receiverRegistered) {
            unregisterReceiver(packageReceiver)
            receiverRegistered = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && IMMERSIVE_MODE) {
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    // ---------- Навигатор ----------

    private fun showNav(info: NavInfo?) {
        if (info == null) {
            wazeLine1.setText(R.string.waze_hint)
            wazeLine2.visibility = View.GONE
            return
        }
        wazeLine1.text = info.line1
        wazeLine2.text = info.line2
        wazeLine2.visibility = if (info.line2.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun openWaze() {
        val intent = packageManager.getLaunchIntentForPackage(MediaListenerService.WAZE_PACKAGE)
        if (intent != null) {
            safeStart(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        // Waze не установлен: пробуем открыть его страницу в магазине приложений
        Toast.makeText(this, R.string.waze_missing, Toast.LENGTH_SHORT).show()
        safeStart(
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${MediaListenerService.WAZE_PACKAGE}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ---------- Скорость ----------

    private fun showSpeed(kmh: Int?) {
        speedValue.text = kmh?.toString() ?: getString(R.string.speed_unknown)
    }

    // ---------- Что сейчас играет ----------

    private fun showTrack(track: Track?) {
        currentTrack = track

        // Кнопки бледнеют, когда управлять нечем
        controls.alpha = if (track == null) 0.4f else 1f
        btnPlay.setImageResource(if (track?.playing == true) R.drawable.ic_pause else R.drawable.ic_play)

        if (track == null) {
            showPlaceholder()
            trackTitle.setText(R.string.audio)
            trackArtist.setText(
                if (tracker.hasAccess()) R.string.nothing_playing else R.string.allow_access
            )
            return
        }

        trackTitle.text = track.title
        trackArtist.text = track.artist

        val art = track.art
        if (art != null) {
            val rounded = RoundedBitmapDrawableFactory.create(resources, art).apply {
                cornerRadius = 16f * resources.displayMetrics.density
                setAntiAlias(true)
            }
            albumArt.scaleType = ImageView.ScaleType.FIT_CENTER
            albumArt.alpha = 1f
            albumArt.setImageDrawable(rounded)
        } else {
            showPlaceholder()
        }
    }

    private fun showPlaceholder() {
        albumArt.scaleType = ImageView.ScaleType.CENTER
        albumArt.alpha = 0.4f
        albumArt.setImageResource(R.drawable.ic_music)
    }

    private fun togglePlayback() {
        val track = currentTrack
        when {
            // Ничего не играет — просто открываем музыкальное приложение
            track == null -> startCategory(Intent.CATEGORY_APP_MUSIC)
            track.playing -> track.controls.pause()
            else -> track.controls.play()
        }
    }

    private fun onAudioTileClick() {
        val sessionIntent = currentTrack?.sessionActivity
        when {
            // Доступа ещё нет — открываем экран, где его можно выдать
            !tracker.hasAccess() -> safeStart(
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )

            // Открываем тот плеер, который сейчас играет
            sessionIntent != null -> try {
                sessionIntent.send()
            } catch (e: PendingIntent.CanceledException) {
                startCategory(Intent.CATEGORY_APP_MUSIC)
            }

            else -> startCategory(Intent.CATEGORY_APP_MUSIC)
        }
    }

    private fun setDrawerVisible(visible: Boolean) {
        drawer.visibility = if (visible) View.VISIBLE else View.GONE
    }

    // ---------- Список приложений ----------

    private fun loadApps() {
        executor.execute {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppInfo(
                        label = it.loadLabel(pm).toString(),
                        packageName = it.activityInfo.packageName,
                        activityName = it.activityInfo.name,
                        icon = it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }

            runOnUiThread { gridAdapter.submit(apps) }
        }
    }

    // ---------- Запуск ----------

    private fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.packageName, app.activityName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        safeStart(intent)
    }

    private fun startCategory(category: String) {
        val intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, category)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        safeStart(intent)
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.app_not_found, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val GRID_COLUMNS = 6

        // true — скрывать системные панели (если у магнитолы есть своя панель, поставьте false)
        private const val IMMERSIVE_MODE = true
    }
}
