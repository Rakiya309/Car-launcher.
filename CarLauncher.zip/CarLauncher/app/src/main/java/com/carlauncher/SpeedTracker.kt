package com.carlauncher

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/**
 * Скорость по GPS в км/ч. onSpeed(null) — скорость неизвестна (нет разрешения, нет сигнала GPS).
 * Вызывать start()/stop() из основного потока.
 */
class SpeedTracker(
    private val context: Context,
    private val onSpeed: (Int?) -> Unit
) {
    private val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val main = Handler(Looper.getMainLooper())

    private var started = false
    private var lastFix = 0L

    // Если GPS-сигнал пропал (например, тоннель), через несколько секунд показываем «--»
    private val timeoutCheck = object : Runnable {
        override fun run() {
            if (!started) return
            if (SystemClock.elapsedRealtime() - lastFix > FIX_TIMEOUT_MS) onSpeed(null)
            main.postDelayed(this, CHECK_INTERVAL_MS)
        }
    }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastFix = SystemClock.elapsedRealtime()
            if (location.hasSpeed()) {
                val kmh = (location.speed * 3.6f).roundToInt()
                // На стоянке GPS «дрожит» на 1–2 км/ч — показываем 0
                onSpeed(if (kmh < 2) 0 else kmh)
            } else {
                onSpeed(null)
            }
        }

        // Эти методы нужно переопределить: на Android до 11 без них приложение падает
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}

        override fun onProviderEnabled(provider: String) {}

        override fun onProviderDisabled(provider: String) {
            onSpeed(null)
        }
    }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun start() {
        started = true
        lastFix = 0L
        onSpeed(null)
        if (!hasPermission()) return

        try {
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, UPDATE_INTERVAL_MS, 0f, listener)
        } catch (e: SecurityException) {
            return
        } catch (e: IllegalArgumentException) {
            // у устройства нет GPS-провайдера
            return
        }
        main.removeCallbacks(timeoutCheck)
        main.postDelayed(timeoutCheck, CHECK_INTERVAL_MS)
    }

    fun stop() {
        started = false
        main.removeCallbacks(timeoutCheck)
        try {
            manager.removeUpdates(listener)
        } catch (e: Exception) {
            // уже снят
        }
    }

    companion object {
        private const val UPDATE_INTERVAL_MS = 1000L
        private const val CHECK_INTERVAL_MS = 2000L
        private const val FIX_TIMEOUT_MS = 5000L
    }
}
